This is our brand new chatbot based on ELIZA.

ELIZA is a conversational agent, or “chatbot”, first implemented in 1966 by Joseph Weizenbaum. It was meant to emulate a Rogerian psychologist. Since then there have been various implementations, more or less similar to the original one. Emacs ships with an ELIZA-type program built in. The CIA even experimented with computer-aided interrogation of officers using a very similar, but rather more combative, version of the program.

My implementation is based on one originally written by Joe Strout. I have updated it significantly to use a more modern and idiomatic form of Python.
